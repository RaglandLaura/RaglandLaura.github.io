#include <stdio>
#include <cs50>

int main(void)


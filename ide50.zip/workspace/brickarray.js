let bricks = []

brick = {

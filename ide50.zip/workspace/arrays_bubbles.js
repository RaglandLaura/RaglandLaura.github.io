
let x;
let y;
let bubbles = [ ];
let bubble;


for (let i = 0; i < 3; i++) {

}

function setup{
    createCanvas(400, 600);
}

function draw{
    background(125);
    ellipse(x, y, 50, 50);

}

function mouseClicked(){
    ellipse(mouseX, mouseY, 50, 50);
}
